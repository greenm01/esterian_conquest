# Unlocked Plain-MZ Bundle

This package swaps in the curated runnable plain-MZ executables from EC_UNLOCKED/ while keeping the same filenames and game layout.

The package contents are:

- `game/`: a minimal real game directory built from a preserved joinable baseline
- `dropfiles/CHAIN.TXT`: the same known-good local-console WWIV dropfile used in `game/`
- `docs/`: the original bundled `.DOC` manuals

## Launch Notes

Use this bundle when you want the stub-free binaries in the same runnable game layout as the classic bundle. The current ECGAME.EXE is rebuilt from the memdump-extracted unlock artifact with corrected MZ size fields so DOS loads the full image.

The included `CHAIN.TXT` is intentionally a local-console file. Its key values are:

- `remote = 0`
- `user baud = 0`
- `COM port = 0`
- `COM baud = 0`

This is a local-console dropfile, not a remote-modem one.

Important launch rules:

- mount `game/` as `C:`
- run plain `ECGAME`
- do not use `/L`
- do not pass `C:\CHAIN.TXT` explicitly

## Known-Good DOSBox-X Command

Run this from the unpacked package root:

```bash
dosbox-x \
  -defaultconf \
  -nopromptfolder \
  -set "dosv=off" \
  -set "machine=vgaonly" \
  -set "core=normal" \
  -set "cputype=386_prefetch" \
  -set "cycles=fixed 3000" \
  -set "xms=false" \
  -set "ems=false" \
  -set "umb=false" \
  -set "output=surface" \
  -c "mount c $PWD/game" \
  -c "c:" \
  -c "mode co80" \
  -c "ECGAME"
```

## Baseline State

The bundled game directory opens into the early join/new-player path rather than a pre-played campaign.
